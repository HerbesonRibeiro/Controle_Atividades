class ClientConfig(object):
    PUBLIC_KEY = 'None'
    APP_NAME = 'controle-atividades'
    COMPANY_NAME = 'Herbeson Ribeiro'
    HTTP_TIMEOUT = 30
    MAX_DOWNLOAD_RETRIES = 3
    UPDATE_URLS = ['https://api.github.com/repos/HerbesonRibeiro/Controle_Atividades/releases/']
